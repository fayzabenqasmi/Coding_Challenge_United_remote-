-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jun 27, 2017 at 06:14 م
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laravel`
--

-- --------------------------------------------------------

--
-- Table structure for table `devoirs`
--

CREATE TABLE `devoirs` (
  `id` int(10) UNSIGNED NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `classe` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `titre` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `devoirs`
--

INSERT INTO `devoirs` (`id`, `body`, `classe`, `titre`, `user_id`, `created_at`, `updated_at`) VALUES
(1, 'Bonjour, j\'ai deposer le  TD 1 de la POO dans le tirage, bonne journee ', 'LSI1', 'Devoir C++', 2, '2017-06-22 16:55:39', '2017-06-22 16:55:39'),
(2, 'Le controle final du module BDD sera ce jeudi, bonne chance ', 'LSI1', 'CONTROLE BASE DE DONNEES ', 2, '2017-06-22 16:56:28', '2017-06-22 16:56:28'),
(3, 'bonjour, le cc de la TG sera ce vendredi, Bon courage', 'LSI3', 'CC THEORIE DE GRAPHE', 2, '2017-06-22 16:57:09', '2017-06-22 16:57:09'),
(4, 'Bonjour, j\'ai deposer l\'enonce du projet dans le tirage, bon courage ', 'LSI2', 'Projet de fin de module de PHP ', 2, '2017-06-22 16:57:49', '2017-06-22 16:57:49'),
(5, 'Bonjour, j\'ai deposer le td 3 dans le tirage, bonne chance ', 'LSI2', 'Devoir module Statistique', 3, '2017-06-22 17:04:54', '2017-06-22 17:04:54'),
(6, 'Bonjour, le cc de la probabilite sera programme pour ce mardi, bon courage ', 'LSI2', 'CC PROBABILITE', 3, '2017-06-22 17:05:37', '2017-06-22 17:05:37'),
(8, 'Bonjour, le rattrapage de la TG sera programme pour ce samedi, bonne chance ', 'LSI3', 'Rattrapage Theorie de graphe', 3, '2017-06-22 17:16:28', '2017-06-22 17:16:28');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(17, '2014_10_12_000000_create_users_table', 1),
(18, '2014_10_12_100000_create_password_resets_table', 1),
(19, '2017_06_22_031130_create_devoirs_table', 1),
(24, '2017_06_23_015633_create_semestres_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `semestres`
--

CREATE TABLE `semestres` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `note1_lsi1_s1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note2_lsi1_s1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note3_lsi1_s1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note4_lsi1_s1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note5_lsi1_s1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note6_lsi1_s1` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note1_lsi1_s2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note2_lsi1_s2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note3_lsi1_s2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note4_lsi1_s2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note5_lsi1_s2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note6_lsi1_s2` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note1_lsi2_s3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note2_lsi2_s3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note3_lsi2_s3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note4_lsi2_s3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note5_lsi2_s3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note6_lsi2_s3` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note1_lsi2_s4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note2_lsi2_s4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note3_lsi2_s4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note4_lsi2_s4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note5_lsi2_s4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note6_lsi2_s4` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note1_lsi3_s5` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note2_lsi3_s5` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note3_lsi3_s5` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note4_lsi3_s5` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note5_lsi3_s5` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note6_lsi3_s5` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `note_lsi3_pfe` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `semestres`
--

INSERT INTO `semestres` (`id`, `created_at`, `updated_at`, `user_id`, `note1_lsi1_s1`, `note2_lsi1_s1`, `note3_lsi1_s1`, `note4_lsi1_s1`, `note5_lsi1_s1`, `note6_lsi1_s1`, `note1_lsi1_s2`, `note2_lsi1_s2`, `note3_lsi1_s2`, `note4_lsi1_s2`, `note5_lsi1_s2`, `note6_lsi1_s2`, `note1_lsi2_s3`, `note2_lsi2_s3`, `note3_lsi2_s3`, `note4_lsi2_s3`, `note5_lsi2_s3`, `note6_lsi2_s3`, `note1_lsi2_s4`, `note2_lsi2_s4`, `note3_lsi2_s4`, `note4_lsi2_s4`, `note5_lsi2_s4`, `note6_lsi2_s4`, `note1_lsi3_s5`, `note2_lsi3_s5`, `note3_lsi3_s5`, `note4_lsi3_s5`, `note5_lsi3_s5`, `note6_lsi3_s5`, `note_lsi3_pfe`) VALUES
(1, NULL, '2017-06-24 19:06:52', 4, '15', '14', '15', '12', '15', '18', '20', '14', '15', '11', '5', '12', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(2, NULL, '2017-06-24 19:24:31', 7, '13', '14', '15', '13', '8', '10', '14', '2', '13', '15', '13', '16', '13', '18', '19', '12', '14', '11', '13', '15', '7', '9', '8', '12', '', '', '', '', '', '', ''),
(3, NULL, '2017-06-25 03:23:08', 8, '13', '12', '15', '9', '17', '7', '15', '18', '11', '10', '10.5', '12', '15', '13', '13', '18', '12', '17', '14', '11', '7', '8', '10.5', '11', '12', '7', '19', '13', '13', '15', '17');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `classe` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `CNE` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'student',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `classe`, `photo`, `CNE`, `Role`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin@hotmail.com', '$2y$10$VRZ9Kbn1A00g.eH7orjFveCesucKdmhMzGh/kLHop2ifVClGWIaPi', 'Admin', 'http://megaicons.net/static/img/icons_sizes/51/200/512/admin-icon.png', 'k503030', 'admin', 'XvtlDG5BacD44O76KcFlONaFE3JYRxtBF9v4iyAElr98ym244gM6WVj98v2f', NULL, NULL),
(2, 'fenan', 'fenan@hotmail.com', '$2y$10$okUXc3I26bvz..jOcq06m.Lv2UlTaqxcIERuGrJj/h/BqPftfc4dG', 'Professeur', 'http://megaicons.net/static/img/icons_sizes/51/200/512/admin-icon.png', 'k52010', 'Professeur', 'vsk11mBfQXWJINpLPj0AwNzmEmQhBNuCPMWnYQFmYuLUxbEdtNa0hAWgbiYv', NULL, '2017-06-22 16:58:28'),
(3, 'Amrani ', 'amrani@hotmail.com', '$2y$10$9DwkEnB4tQIEs5UInTviyOWV382gNUWavcebA/gowcFj7Ln9QeUze', 'Professeur', 'http://megaicons.net/static/img/icons_sizes/51/200/512/admin-icon.png', 'k52011', 'Professeur', 'NJEniTF7ypyCw4UBEr6cLl41OnXbHoK4ncP0pLx9I4zKDRkavf2zE73jXJBW', NULL, '2017-06-22 17:18:05'),
(4, 'Saad joudi', 'joudii_1994@hotmail.com', '$2y$10$Ekf4sMRnx1deTqL6eWycve.TMIbdbjtTERllxDVWvov9mNGZ/hdTK', 'LSI1', 'http://megaicons.net/static/img/icons_sizes/51/200/512/admin-icon.png', 'k502253', 'student', 'aXuQSjVlWGIpJlTGkuj61JBm9YUBkBMG5HLGUc9goD7OUEHFUSMol826cxLk', NULL, '2017-06-22 17:00:44'),
(6, 'Ayoub bakkali', 'ayoub@hotmail.com', '$2y$10$s2azyBWJRbJE5fQRDluWLePPVjWUFImdD4YAdVMnXjBm3fP8dhVFC', 'LSI2', 'http://hairstyles.thehairstyler.com/hairstyle_views/front_view_images/7493/original/Justin-Timberlake.jpg', 'k30320', 'student', 'HcCBrp9UZ7HpDTGutFOr6foyyy9ZQQFeijsUwAApwVbKV8jmeOg4lO7qRGzA', '2017-06-22 17:35:52', '2017-06-22 17:36:18'),
(7, 'Saad joudi', 'saadjoudi@gmail.com', '$2y$10$0eQiVTmV29cZCXzTjjOkYOve28JGFGgrepaA//KJ2yVsejSJvnvW6', 'LSI2', 'https://www.france.tv/image/carre/300/300/e/n/k/8bb21aac-phpfgokne.jpg', '     K30302', 'student', 'FC1stVOVJvUSp0w8fyPjUxBOAD2zbRLPk0EXDiy4ySd1Ync0NuK0326X7pZh', '2017-06-23 02:52:52', '2017-06-25 04:08:09'),
(8, 'Etudiant lsi3', 'etudiant@hotmail.com', '$2y$10$VIfwjr0ZapGnoKVadAav3uY0ZD1o91HSDRhN3dtKEQDo.nlDNRLCa', 'LSI3', 'http://hairstyles.thehairstyler.com/hairstyle_views/front_view_images/7493/original/Justin-Timberlake.jpg', 'k223010', 'student', 'fur4pggbRIV44xgvUjrxz02ZIFl2H9P3WkR0UARdqAycMRWFgXz7PuHXnnmd', '2017-06-24 06:11:29', '2017-06-24 06:11:29');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `devoirs`
--
ALTER TABLE `devoirs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `semestres`
--
ALTER TABLE `semestres`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `devoirs`
--
ALTER TABLE `devoirs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `semestres`
--
ALTER TABLE `semestres`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
