<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading" style="text-align:center;font-size: 20px"> <?php echo e(Auth::user()->name); ?></div>

                <div class="panel-body">
                    <div class="col-md-4">
                         <img src = "<?php echo e(Auth::user()->photo); ?>" style="height:200px;width: 200px">
                    </div>
                    <div class="col-md-6">
                        <div style="margin-top:20px;margin-left:20px;margin-top:50px">Full name : <?php echo e(Auth::user()->name); ?> </div>
                        <div style="margin-top:20px;margin-left:20px">Email : <?php echo e(Auth::user()->email); ?></div>
                        <div style="margin-top:20px;margin-left:20px">CNE : <?php echo e(Auth::user()->CNE); ?></div>
                        <div style="margin-top:20px;margin-left:20px">Class : <?php echo e(Auth::user()->classe); ?></div>

                    </div>
                </div>

            </div>
            <div class="col-md-9"></div>
            <a class="btn btn-success" href="<?php echo e(route('modifierProfil')); ?>"> Modifier les informations </a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>