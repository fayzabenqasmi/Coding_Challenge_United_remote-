<?php $__env->startSection('content'); ?>
<div class="container">


		<h1> Bonjour monsieur <?php echo e(Auth::user()->name); ?> </h1>
		<a type="button" href="getPublierDevoir" class="btn btn-primary btn-lg">Publier</a>
		<a type="button" href="getProfesseurDevoir" class="btn btn-success btn-lg">Afficher mes publications</a>
	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>