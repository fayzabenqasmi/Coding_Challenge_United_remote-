<?php $__env->startSection('content'); ?>
<div class="container">

	<h2 style="margin-bottom:50px; padding:10px" class="bg-primary">Vos publications : </h2>
	<div class="row">
	<div class="col-md-12" style="margin-bottom:20px"><a href="professeurPage" class="btn btn-success glyphicon glyphicon-arrow-left"> Retour </a></div>
	<?php $__currentLoopData = $devoirs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $devoir): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if(Auth::user()->id == $devoir->user_id): ?>
		  <div class="col-sm-4">
		    <div class="thumbnail" style="border-top-right-radius: 50px;border-bottom-left-radius: 80px">
		     
		      <div class="caption">
		        <h3 style="text-align:center;"><span style="color:#3097D1;text-decoration: underline;"><?php echo e($devoir->classe); ?> : <?php echo e($devoir->titre); ?></span></h3>
		        <p style="text-align:center;margin-bottom:30px;font-style: italic;"> Publie le :<?php echo e($devoir->created_at); ?></p>
		        <p style="text-align:center"><?php echo e($devoir->body); ?></p>
		        <form method="POST" action="supprimerDevoir">
		        	<?php echo e(csrf_field()); ?>

			        <input type="hidden" name="id_devoir" value="<?php echo e($devoir->id); ?>">
			        <p style="text-align:center"><input type="submit" class="btn btn-primary" role="button" value="Supprimer"></p>
		        </form>
		      </div>
		    </div>
		  </div>
		
		<?php endif; ?>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>