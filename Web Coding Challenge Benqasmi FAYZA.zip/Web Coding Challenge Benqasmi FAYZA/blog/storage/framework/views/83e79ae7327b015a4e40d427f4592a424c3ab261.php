<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-3"><a href="profil" class="btn btn-primary glyphicon glyphicon-arrow-left"> Retour </a></div>
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading" style="text-align:center;font-size: 20px"> Modifier profil </div>

                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST" action="modifierProfilFunction" style="padding: 10px">
                        <?php echo e(csrf_field()); ?>


                        <div class="form-group" style="margin-top: 50px">
                            <label for="email" class="col-md-4 control-label">Name</label>

                            <div class="col-md-6">
                                <input id="email" type="text" value="<?php echo e(Auth::user()->name); ?>" class="form-control" name="name" required autofocus>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input id="email" type="email" value="<?php echo e(Auth::user()->email); ?>" class="form-control" name="email" required autofocus>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="email" class="col-md-4 control-label"> CNE :</label>

                            <div class="col-md-6">
                                <input id="email" type="text" value="<?php echo e(Auth::user()->CNE); ?>" class="form-control" name="CNE" required autofocus>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="email" class="col-md-4 control-label"> PHOTO :</label>

                            <div class="col-md-6">
                                <input id="email" type="text" value="<?php echo e(Auth::user()->photo); ?>" class="form-control" name="photo" required autofocus>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="email" class="col-md-4 control-label"> Class :</label>

                            <div class="col-md-6">
                                <input id="email" type="text" value="<?php echo e(Auth::user()->classe); ?>" class="form-control" name="classe" required autofocus>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="email" class="col-md-4 control-label"> Password :</label>

                            <div class="col-md-6">
                                <input id="email" type="password"  class="form-control" name="password" required autofocus>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-8 col-md-offset-4">
                                <input type="submit" value="Confirmer" class="btn btn-success" style="background-color: rgba(40, 109, 53,1);">
                            </div>
                        </div>
                    </form>
                
                </div>

            </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>