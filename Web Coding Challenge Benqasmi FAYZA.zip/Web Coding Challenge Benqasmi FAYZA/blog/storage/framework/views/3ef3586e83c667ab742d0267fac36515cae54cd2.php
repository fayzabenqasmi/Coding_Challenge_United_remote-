<?php $__env->startSection('content'); ?>
<div class="container">

	<h1 style="margin-bottom:50px;padding:10px" class="bg-primary">Filiere <?php echo e(Auth::user()->classe); ?>: </h1>
	<div class="row">
    <?php $__currentLoopData = $devoirs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $devoir): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if( $devoir->classe == Auth::user()->classe ): ?>
        	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        		<?php if( $user->id == $devoir->user_id): ?>

				  <div class="col-sm-4">
				    <div class="thumbnail" style="border-top-right-radius: 50px;border-bottom-left-radius: 80px">
				     
				      <div class="caption">
				        <h3 style="text-align:center;"><span style="color:#3097D1;text-decoration: underline;"> <?php echo e($devoir->titre); ?></span></h3>
				        <p style="text-align:center;margin-bottom:30px;font-style: italic;"> Publie le :<?php echo e($devoir->created_at); ?> par : <?php echo e($user->name); ?></p>
				        <p style="text-align:center"><?php echo e($devoir->body); ?></p>	
				        </form>
				      </div>
				    </div>
				  </div>



        		<?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>