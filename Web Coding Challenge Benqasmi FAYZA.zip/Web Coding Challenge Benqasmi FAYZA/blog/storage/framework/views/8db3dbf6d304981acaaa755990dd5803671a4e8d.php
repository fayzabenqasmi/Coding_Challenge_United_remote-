<?php $__env->startSection('content'); ?>

  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($user->id == Auth::user()->id ): ?>
        <?php if( $user->classe == 'LSI1'): ?>
          <?php $cmp = 0 ?>
          <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($note->user_id == Auth::user()->id ): ?>
              <?php $cmp ++ ?>

              <div class="container">
                    <a href="profil" class="btn btn-primary glyphicon glyphicon-arrow-left"> Retour </a>
                    <h2 class="bg-primary" style="padding: 10px;">Notes de <?php echo e($user->name); ?></h2>
                
                    <div class="row">  
                    <!-- NOTES S1 -->
                      <div class="col-md-6"> 
                      <div class="jumbotron">
                              <p class="text-primary" style="text-decoration:underline;text-align: center">Les notes de S1 : </p>         
                              <table class="table table-condensed">
                                <thead>
                                  <tr>
                                    <th> Matiere </th>
                                    <th> Note </th>
                                    
                                  </tr>
                                </thead>
                                <tbody>
                                  <tr>
                                    <td> Mathématiques pour l’ingénieur </td>
                                    <td> <?php echo e($note->note1_lsi1_s1); ?></td>
                                  </tr>
                                  <tr>
                                    <td> Systèmes d’exploitation et systèmes embarqués </td>
                                    <td> <?php echo e($note->note2_lsi1_s1); ?></td>

                                  </tr>
                                  <tr>
                                    <td>  Architecture des ordinateurs </td>
                                    <td> <?php echo e($note->note3_lsi1_s1); ?></td>

                                  </tr>
                                  <tr>
                                    <td> Programmation C  et Structures de données</td>
                                    <td> <?php echo e($note->note4_lsi1_s1); ?></td>

                                  </tr>
                                  <tr>
                                    <td>  Architecture des réseaux informatiques</td>
                                    <td> <?php echo e($note->note5_lsi1_s1); ?></td>
                                  </tr>
                                  <tr>
                                    <td> Systèmes d’informations relationnelles et langage des requêtes</td>
                                    <td> <?php echo e($note->note6_lsi1_s1); ?></td>

                                  </tr>

                                </tbody>
                              </table>
                      </div>
                      </div>
                      <!-- S2 NOTES -->


                      <div class="col-md-6"> 
                      <div class="jumbotron">
                              <p class="text-primary" style="text-decoration:underline;text-align: center">Les notes de S2: </p>         
                              <table class="table table-condensed">
                                <thead>
                                  <tr>
                                    <th> Matiere </th>
                                    <th> Note </th>
                                    
                                  </tr>
                                </thead>
                                <tbody>
                                  <tr>
                                    <td> Urbanisation des SI et Conduite des projets Informatique </td>
                                    <td> <?php echo e($note->note1_lsi1_s2); ?></td>

                                  </tr>
                                  <tr>
                                    <td> Développement web et Frameworks </td>
                                    <td> <?php echo e($note->note2_lsi1_s2); ?></td>

                                  </tr>
                                  <tr>
                                    <td>  Statistique descriptive et inferentielle </td>
                                    <td> <?php echo e($note->note3_lsi1_s2); ?></td>

                                  </tr>
                                  <tr>
                                    <td> Modélisation orientée objet et Programmation C++</td>
                                    <td> <?php echo e($note->note4_lsi1_s2); ?></td>

                                  </tr>
                                  <tr>
                                    <td> Théorie des graphes et Applications</td>
                                    <td> <?php echo e($note->note5_lsi1_s2); ?></td>

                                  </tr>
                                  <tr>
                                    <td>Gestion de L’innovation et management de projet </td>
                                    <td> <?php echo e($note->note6_lsi1_s2); ?></td>

                                  </tr>

                                </tbody>
                              </table>
                      </div>
                      </div>
                  </div>
          </div>

                <?php endif; ?>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php if($cmp == 0): ?>
          <div class="container">
               <a href="profil" class="btn btn-primary glyphicon glyphicon-arrow-left"> Retour </a>
              <div class="alert alert-info" role="alert">
                <strong>Info !</strong> Pas encore remplis 
              </div>
          </div>
          <?php endif; ?>


        


        <?php elseif($user->classe == 'LSI2'): ?>


        <!-- S1 + S2 + S3 + S4 -->
           <?php $cmp = 0 ?>
          <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             
              <?php if($note->user_id == Auth::user()->id ): ?>
              <?php $cmp ++ ?>

              <div class="container">
               <a href="profil" class="btn btn-primary glyphicon glyphicon-arrow-left"> Retour </a>
                <h2 class="bg-primary" style="padding:10px">Notes de <?php echo e($user->name); ?></h2>
                
                    <div class="row">  
                    <!-- NOTES S1 -->
                      <div class="col-md-6"> 
                      <div class="jumbotron">
                              <p class="text-primary" style="text-decoration:underline;text-align: center">Les notes de S1 : </p>         
                              <table class="table table-condensed">
                                <thead>
                                  <tr>
                                    <th> Matiere </th>
                                    <th> Note </th>
                                   
                                  </tr>
                                </thead>
                                <tbody>
                                  <tr>
                                    <td> Mathématiques pour l’ingénieur </td>
                                    <td> <?php echo e($note->note1_lsi1_s1); ?></td>

                                  </tr>
                                  <tr>
                                    <td> Systèmes d’exploitation et systèmes embarqués </td>
                                    <td> <?php echo e($note->note2_lsi1_s1); ?></td>

                                  </tr>
                                  <tr>
                                    <td>  Architecture des ordinateurs </td>
                                    <td> <?php echo e($note->note3_lsi1_s1); ?></td>
   
                                  </tr>
                                  <tr>
                                    <td> Programmation C  et Structures de données</td>
                                    <td> <?php echo e($note->note4_lsi1_s1); ?></td>

                                  </tr>
                                  <tr>
                                    <td>  Architecture des réseaux informatiques</td>
                                    <td> <?php echo e($note->note5_lsi1_s1); ?></td>

                                  </tr>
                                  <tr>
                                    <td> Systèmes d’informations relationnelles et langage des requêtes</td>
                                    <td> <?php echo e($note->note6_lsi1_s1); ?></td>

                                  </tr>

                                </tbody>
                              </table>
                      </div>
                      </div>
                      <!-- S2 NOTES -->


                      <div class="col-md-6"> 
                      <div class="jumbotron">
                              <p class="text-primary" style="text-decoration:underline;text-align: center">Les notes de S2: </p>         
                              <table class="table table-condensed">
                                <thead>
                                  <tr>
                                    <th> Matiere </th>
                                    <th> Note </th>
                                    
                                  </tr>
                                </thead>
                                <tbody>
                                  <tr>
                                    <td> Urbanisation des SI et Conduite des projets Informatique </td>
                                    <td> <?php echo e($note->note1_lsi1_s2); ?></td>

                                  </tr>
                                  <tr>
                                    <td> Développement web et Frameworks </td>
                                    <td> <?php echo e($note->note2_lsi1_s2); ?></td>

                                  </tr>
                                  <tr>
                                    <td>  Statistique descriptive et inferentielle </td>
                                    <td> <?php echo e($note->note3_lsi1_s2); ?></td>

                                  </tr>
                                  <tr>
                                    <td> Modélisation orientée objet et Programmation C++</td>
                                    <td> <?php echo e($note->note4_lsi1_s2); ?></td>

                                  </tr>
                                  <tr>
                                    <td> Théorie des graphes et Applications</td>
                                    <td> <?php echo e($note->note5_lsi1_s2); ?></td>

                                  </tr>
                                  <tr>
                                    <td>Gestion de L’innovation et management de projet </td>
                                    <td> <?php echo e($note->note6_lsi1_s2); ?></td>
 
                                  </tr>

                                </tbody>
                              </table>
                      </div>
                      </div>
                  

                <!-- NOTES S3 -->
               
                  <div class="col-md-6"> 
                  <div class="jumbotron">
                          <p class="text-primary" style="padding: 10px;text-align: center;text-decoration: underline;">Les notes de S3 : </p>         
                          <table class="table table-condensed">
                            <thead>
                              <tr>
                                <th> Matiere </th>
                                <th> Note </th>
                                
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td> Programmation Java et Programmation mobile </td>
                                <td> <?php echo e($note->note1_lsi2_s3); ?></td>

                              </tr>
                              <tr>
                                <td> Administration des bases de données  </td>
                                <td> <?php echo e($note->note2_lsi2_s3); ?></td>

                              </tr>
                              <tr>
                                <td>  INTERNET DES OBJETS  et Architectures Mobile </td>
                                <td> <?php echo e($note->note3_lsi2_s3); ?></td>

                              </tr>
                              <tr>
                                <td>Administration réseaux et systèmes</td>
                                <td> <?php echo e($note->note4_lsi2_s3); ?></td>

                              </tr>
                              <tr>
                                <td>  Méthodologies de l'Intelligence Artificielles</td>
                                <td> <?php echo e($note->note5_lsi2_s3); ?></td>

                              </tr>
                              <tr>
                                <td> Anglais avancé et techniques d’exposition </td>
                                <td> <?php echo e($note->note6_lsi2_s3); ?></td>

                              </tr>

                            </tbody>
                          </table>
              </div>
              </div>

                <!-- NOTES S4 -->
                  <div class="col-md-6">
                  <div class="jumbotron"> 
                          <p class="text-primary" style="padding: 10px;text-align: center;text-decoration: underline;">Les notes de S4 : </p>         
                          <table class="table table-condensed">
                            <thead>
                              <tr>
                                <th> Matiere </th>
                                <th> Note </th>
                                
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td> Architectures web distribuées   (j2ee) </td>
                                <td> <?php echo e($note->note1_lsi2_s4); ?></td>

                              </tr>
                              <tr>
                                <td> Systèmes Multi-Agents et Systèmes Multi-Experts   </td>
                                <td> <?php echo e($note->note2_lsi2_s4); ?></td>

                              </tr>
                              <tr>
                                <td>  Vision Artificielle </td>
                                <td> <?php echo e($note->note3_lsi2_s4); ?></td>

                              </tr>
                              <tr>
                                <td> Technologies .NET</td>
                                <td> <?php echo e($note->note4_lsi2_s4); ?></td>

                              </tr>
                              <tr>
                                <td>  Techniques Avancées en Génie  logiciel</td>
                                <td> <?php echo e($note->note5_lsi2_s4); ?></td>

                              </tr>
                              <tr>
                                <td> Ressources de planification d'entreprise  (Open Erp) </td>
                                <td> <?php echo e($note->note6_lsi2_s4); ?></td>

                              </tr>

                            </tbody>
                          </table>
                  </div>
                  </div>
            </div>
            </div>

              <?php endif; ?>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php if($cmp == 0): ?>
    
          <div class="container">
               <a href="profil" class="btn btn-primary glyphicon glyphicon-arrow-left"> Retour </a>
              <div class="alert alert-info" role="alert">
                <strong>Info !</strong> Pas encore remplis 
              </div>
          </div>
       
                    
          <?php endif; ?>



      <!-- NOTES LSI3 -->

        <?php elseif($user->classe == 'LSI3'): ?>

        <!-- S1 + S2 + S3 + S4 S5 + S6  -->
          <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $cmp = 0 ?>
              <?php if($note->user_id == Auth::user()->id ): ?>
              <?php $cmp ++ ?>

              <div class="container">
              	<div class="col-md-12">
                <a href="profil" class="btn btn-primary glyphicon glyphicon-arrow-left"> Retour </a>
                <h2 class="bg-primary" style="padding:10px">Notes de <?php echo e($user->name); ?></h2>
                </div>
                    <div class="row">  
                    <!-- NOTES S1 -->
                      <div class="col-md-6"> 
                      <div class="jumbotron">
                              <p class="text-primary" style="text-decoration:underline;text-align: center">Les notes de S1 : </p>         
                              <table class="table table-condensed">
                                <thead>
                                  <tr>
                                    <th> Matiere </th>
                                    <th> Note </th>
                                   
                                  </tr>
                                </thead>
                                <tbody>
                                  <tr>
                                    <td> Mathématiques pour l’ingénieur </td>
                                    <td> <?php echo e($note->note1_lsi1_s1); ?></td>

                                  </tr>
                                  <tr>
                                    <td> Systèmes d’exploitation et systèmes embarqués </td>
                                    <td> <?php echo e($note->note2_lsi1_s1); ?></td>

                                  </tr>
                                  <tr>
                                    <td>  Architecture des ordinateurs </td>
                                    <td> <?php echo e($note->note3_lsi1_s1); ?></td>

                                  </tr>
                                  <tr>
                                    <td> Programmation C  et Structures de données</td>
                                    <td> <?php echo e($note->note4_lsi1_s1); ?></td>

                                  </tr>
                                  <tr>
                                    <td>  Architecture des réseaux informatiques</td>
                                    <td> <?php echo e($note->note5_lsi1_s1); ?></td>

                                  </tr>
                                  <tr>
                                    <td> Systèmes d’informations relationnelles</td>
                                    <td> <?php echo e($note->note6_lsi1_s1); ?></td>

                                  </tr>

                                </tbody>
                              </table>
                      </div>
                      </div>
                      <!-- S2 NOTES -->


                      <div class="col-md-6"> 
                      <div class="jumbotron">
                              <p class="text-primary" style="text-decoration:underline;text-align: center">Les notes de S2: </p>         
                              <table class="table table-condensed">
                                <thead>
                                  <tr>
                                    <th> Matiere </th>
                                    <th> Note </th>
                                   
                                  </tr>
                                </thead>
                                <tbody>
                                  <tr>
                                    <td> Urbanisation des SI et Conduite des projets Informatique </td>
                                    <td> <?php echo e($note->note1_lsi1_s2); ?></td>

                                  </tr>
                                  <tr>
                                    <td> Développement web et Frameworks </td>
                                    <td> <?php echo e($note->note2_lsi1_s2); ?></td>


                                    </td>
                                  </tr>
                                  <tr>
                                    <td>  Statistique descriptive et inferentielle </td>
                                    <td> <?php echo e($note->note3_lsi1_s2); ?></td>

                                  </tr>
                                  <tr>
                                    <td> Modélisation orientée objet et Programmation C++</td>
                                    <td> <?php echo e($note->note4_lsi1_s2); ?></td>

                                  </tr>
                                  <tr>
                                    <td> Théorie des graphes et Applications</td>
                                    <td> <?php echo e($note->note5_lsi1_s2); ?></td>

                                  </tr>
                                  <tr>
                                    <td>Gestion de L’innovation et management de projet </td>
                                    <td> <?php echo e($note->note6_lsi1_s2); ?></td>

                                  </tr>

                                </tbody>
                              </table>
                      </div>
                      </div>
                  

                <!-- NOTES S3 -->
               
                  <div class="col-md-6"> 
                  <div class="jumbotron">
                          <p class="text-primary" style="padding: 10px;text-align: center;text-decoration: underline;">Les notes de S3 : </p>         
                          <table class="table table-condensed">
                            <thead>
                              <tr>
                                <th> Matiere </th>
                                <th> Note </th>
                                
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td> Programmation Java et Programmation mobile </td>
                                <td> <?php echo e($note->note1_lsi2_s3); ?></td>

                              </tr>
                              <tr>
                                <td> Administration des bases de données  </td>
                                <td> <?php echo e($note->note2_lsi2_s3); ?></td>

                              </tr>
                              <tr>
                                <td>  INTERNET DES OBJETS  et Architectures Mobile </td>
                                <td> <?php echo e($note->note3_lsi2_s3); ?></td>

                              </tr>
                              <tr>
                                <td>Administration réseaux et systèmes</td>
                                <td> <?php echo e($note->note4_lsi2_s3); ?></td>

                              </tr>
                              <tr>
                                <td>  Méthodologies de l'Intelligence Artificielles</td>
                                <td> <?php echo e($note->note5_lsi2_s3); ?></td>

                              </tr>
                              <tr>
                                <td> Anglais avancé et techniques d’exposition </td>
                                <td> <?php echo e($note->note6_lsi2_s3); ?></td>

                              </tr>

                            </tbody>
                          </table>
              </div>
              </div>

                <!-- NOTES S4 -->
                  <div class="col-md-6">
                  <div class="jumbotron"> 
                          <p class="text-primary" style="padding: 10px;text-align: center;text-decoration: underline;">Les notes de S4 : </p>         
                          <table class="table table-condensed">
                            <thead>
                              <tr>
                                <th> Matiere </th>
                                <th> Note </th>
                                
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td> Architectures web distribuées   (j2ee) </td>
                                <td> <?php echo e($note->note1_lsi2_s4); ?></td>

                              </tr>
                              <tr>
                                <td> Systèmes Multi-Agents et Systèmes Multi-Experts   </td>
                                <td> <?php echo e($note->note2_lsi2_s4); ?></td>

                              </tr>
                              <tr>
                                <td>  Vision Artificielle </td>
                                <td> <?php echo e($note->note3_lsi2_s4); ?></td>

                              </tr>
                              <tr>
                                <td> Technologies .NET</td>
                                <td> <?php echo e($note->note4_lsi2_s4); ?></td>

                              </tr>
                              <tr>
                                <td>  Techniques Avancées en Génie  logiciel</td>
                                <td> <?php echo e($note->note5_lsi2_s4); ?></td>

                              </tr>
                              <tr>
                                <td> Ressources de planification d'entreprise  (Open Erp) </td>
                                <td> <?php echo e($note->note6_lsi2_s4); ?></td>

                              </tr>

                            </tbody>
                          </table>
                  </div>
                  </div>

                <!-- NOTES S5 -->
                  <div class="col-md-6">
                  <div class="jumbotron"> 
                          <p class="text-primary" style="padding: 10px;text-align: center;text-decoration: underline;">Les notes de S5 : </p>         
                          <table class="table table-condensed">
                            <thead>
                              <tr>
                                <th> Matiere </th>
                                <th> Note </th>
                                
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td> Processus d'évaluation et Qualité des Logiciels </td>
                                <td> <?php echo e($note->note1_lsi3_s5); ?></td>

                              </tr>
                              <tr>
                                <td> Audit et Sécurité Intélligentedes systèmes d’informations   </td>
                                <td> <?php echo e($note->note2_lsi3_s5); ?></td>

                              </tr>
                              <tr>
                                <td>  Systèmes d’informations décisionnel et data mininig </td>
                                <td> <?php echo e($note->note3_lsi3_s5); ?></td>

                              </tr>
                              <tr>
                                <td> Cloud Intelligence et virtulisation</td>
                                <td> <?php echo e($note->note4_lsi3_s5); ?></td>

                              </tr>
                              <tr>
                                <td>  Géodecisionnel et Systèmes d’informations géographiques</td>
                                <td> <?php echo e($note->note5_lsi3_s5); ?></td>

                              </tr>
                              <tr>
                                <td> Intelligence économique </td>
                                <td> <?php echo e($note->note6_lsi3_s5); ?></td>

                              </tr>
                            </tbody>
                          </table>
                          <p class="text-primary" style="padding: 10px;text-align: center;text-decoration: underline;">Les notes de S6 : </p>
                          
                              <table class="table table-condensed">
                              <tbody>
                              <tr>
                                <td> Projet de fin d’études  </td>
                                <td> <?php echo e($note->note_lsi3_pfe); ?></td>

                              </tr>
                              </tbody>
                              </table>
                         
                  </div>
                  </div>



              </div>
              </div>


          

              <?php endif; ?>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <?php if($cmp == 0): ?>
          <div class="container">
               <a href="profil" class="btn btn-primary glyphicon glyphicon-arrow-left"> Retour </a>
              <div class="alert alert-info" role="alert">
                <strong>Info !</strong> Pas encore remplis 
              </div>
          </div>
                    
          <?php endif; ?>






        

        <?php else: ?>


          <h1> Filiere introuvable </h1>

        <?php endif; ?>


    <?php endif; ?>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>