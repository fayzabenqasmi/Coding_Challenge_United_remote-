<?php $__env->startSection('content'); ?>
<div class="container">
	 		<div class="col-md-3"><a href="administration" class="btn btn-primary glyphicon glyphicon-arrow-left"> Retour </a></div>
		    <div class="col-md-12">
		        <h3 style="text-align:center;padding:10px" class="bg-primary"">Etudiants de lsi 3 </h3>
		         <div class="row" style="margin-top:50px">
		      	 <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		   		 <?php if($user->classe == 'LSI3'): ?>
			        <div class="col-sm-4">
			            <div class="card">
			                <canvas class="header-bg" width="250" height="70" id="header-blur"></canvas>
			                <div class="avatar">
			                    <img style="width:100px" src="<?php echo e($user->photo); ?>" alt="" />
			                </div>
			                <div class="content">
			                    <p><?php echo e($user->name); ?> <br>
			                       CNE : <?php echo e($user->CNE); ?> <br>
			                       EMAIL : <?php echo e($user->email); ?> <br>	

			                    </p>
								<form method="POST" action="deleteUser">
									 <?php echo e(csrf_field()); ?>			 	   
									<input type="hidden" value="<?php echo e($user->id); ?>" name="user_id">                
				                    <p><input type="submit" class="btn btn-danger" value="supprimer">
			                    </form>

								<form method="POST" action="getUpdateUserAdmin">
									 <?php echo e(csrf_field()); ?>			 	   
									<input type="hidden" value="<?php echo e($user->id); ?>" name="user_id">                
				                    <input type="submit" class="btn btn-primary" value="Modifier"></p>			
			                    </form> 

			                    <form method="POST" action="afficherNotes">
			                    <?php echo e(csrf_field()); ?>

			                    	<input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
			                    	<input type="submit" name="submit" class="btn btn-success" value="Modifier notes">
			                    </form>           
			                </div>
			            </div>
			        </div>
		   		 <?php endif; ?>
		   		 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		   		</div>
			</div>
	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>