<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
	    <div class="col-md-2"><a href="professeurPage" class="btn btn-primary glyphicon glyphicon-arrow-left"> Retour </a></div>
	   
    
	    <div class="col-md-9">
	    						<h3>Publier un devoir </h3>
	    						<div class="widget-area no-padding blank">
									<div class="status-upload">
										<form method="POST" action="publierDevoir">
										<?php echo e(csrf_field()); ?>

											<div class="form-group">
												<label for="sel1">Classe :</label>
												 <select class="form-control" name="classe" id="sel1">
												    <option value="LSI1">LSI 1</option>
												    <option value="LSI2">LSI 2</option>
												    <option value="LSI3">LSI 3</option>
												  </select>
											</div>
											<div class="form-group">
												<label>Titre :</label>
												<input class="form-control" type="text" name="titre">
											</div>
											<textarea name="body" placeholder="Devoir .. " ></textarea>
											<ul>
												<li><a title="" data-toggle="tooltip" data-placement="bottom" data-original-title="Audio"><i class="fa fa-music"></i></a></li>
												<li><a title="" data-toggle="tooltip" data-placement="bottom" data-original-title="Video"><i class="fa fa-video-camera"></i></a></li>
												<li><a title="" data-toggle="tooltip" data-placement="bottom" data-original-title="Sound Record"><i class="fa fa-microphone"></i></a></li>
												<li><a title="" data-toggle="tooltip" data-placement="bottom" data-original-title="Picture"><i class="fa fa-picture-o"></i></a></li>
											</ul>
											<input name="id-user" type="hidden" value="<?php echo e(Auth::user()->id); ?>">	
											<input type="submit" class="btn btn-success" value="Partager">
										</form>
									</div><!-- Status Upload  -->
								</div><!-- Widget Area -->
		</div>
        
    </div>

<script>
$(document).ready(function(){

    
    $("[data-toggle=tooltip]").tooltip();
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>