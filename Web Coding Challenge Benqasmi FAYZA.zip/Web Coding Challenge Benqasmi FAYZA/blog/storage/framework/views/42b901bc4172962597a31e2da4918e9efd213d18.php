<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="col-md-12">
        <h3 style="text-align: center;padding:10px" class="bg-primary"> Filièree LSI  : </h3>
        <div class="list-group" style="text-align: center">
          <a href="<?php echo e(route('lsi1')); ?>" class="list-group-item">LSI 1</a>
          <a href="<?php echo e(route('lsi2')); ?>" class="list-group-item">LSI 2</a>
          <a href="<?php echo e(route('lsi3')); ?>" class="list-group-item">LSI 3</a>
        </div>
    </div>
    
    <div class="col-md-9">
    	<a style="margin-top:62px;;padding:10px" href="<?php echo e(route('getPublications')); ?>" class="btn btn-primary lg"> Consulter les publications </a>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>