<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row">
	
        <div class="col-md-6 col-md-offset-3">
  <h4 style="border-bottom: 1px solid #c5c5c5;">
    <i class="glyphicon glyphicon-pencil">
    </i>
    Modification de la note du module <?php echo e($matiere); ?>

  </h4>
  <div style="padding: 20px;" id="form-olvidado">
  <form accept-charset="UTF-8" role="form" id="login-form" method="post">
  <?php echo e(csrf_field()); ?>

      <fieldset>
        <div class="form-group input-group">
          <span class="input-group-addon">
            Note :
          </span>
          <input class="form-control" placeholder=".." name="nouvelle_note" type="number" step="0.01" min="0" max="20" required="" autofocus="">
        </div>
        <!-- Variables a passer pour la fonction -->

        <input type="hidden" name="note" value="<?php echo e($note); ?>">
        <input type="hidden" nane="id_user" value="<?php echo e($id_user); ?>">
        <div class="form-group">
          <input type="submit" value="Modifier" class="btn btn-primary btn-block">
        </div>
      </fieldset>
    </form>
  </div>

    </form>
  </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>