<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSemestresTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('semestres', function (Blueprint $table) {
            $table->increments('id');
            $table->timestamps();
            $table->integer('user_id');

            $table->text('note1_lsi1_s1'); //Mathématiques pour l’ingénieur
            $table->text('note2_lsi1_s1'); //Systèmes d’exploitation et systèmes embarqués           
            $table->text('note3_lsi1_s1'); //Architecture des ordinateurs
            $table->text('note4_lsi1_s1'); //Programmation C  et Structures de données
            $table->text('note5_lsi1_s1'); //Architecture des réseaux informatiques
            $table->text('note6_lsi1_s1'); //Systèmes d’informations relationnelles et langage des requêtes

            $table->text('note1_lsi1_s2'); //Urbanisation des SI et Conduite des projets Informatique
            $table->text('note2_lsi1_s2'); //Développement web et Frameworks           
            $table->text('note3_lsi1_s2'); //Statistique descriptive et inferentielle
            $table->text('note4_lsi1_s2'); //Modélisation orientée objet et Programmation C++
            $table->text('note5_lsi1_s2'); //Théorie des graphes et Applications
            $table->text('note6_lsi1_s2'); //Gestion de L’innovation et management de projet     

            $table->text('note1_lsi2_s3'); //Programmation Java et Programmation mobile
            $table->text('note2_lsi2_s3'); //Administration des bases de données           
            $table->text('note3_lsi2_s3'); //INTERNET DES OBJETS  et Architectures Mobile
            $table->text('note4_lsi2_s3'); //Administration réseaux et systèmes
            $table->text('note5_lsi2_s3'); //Méthodologies de l'Intelligence Artificielle
            $table->text('note6_lsi2_s3');  //Anglais avancé et techniques d’exposition    

            $table->text('note1_lsi2_s4'); //Architectures web distribuées   (j2ee)
            $table->text('note2_lsi2_s4'); //Systèmes Multi-Agents et Systèmes Multi-Experts       
            $table->text('note3_lsi2_s4'); //Vision Artificielle
            $table->text('note4_lsi2_s4'); //Technologies   .net
            $table->text('note5_lsi2_s4'); //Techniques Avancées en Génie  logiciel
            $table->text('note6_lsi2_s4'); //Ressources de planification d'entreprise  (Open Erp

            $table->text('note1_lsi3_s5'); //Processus d'évaluation et Qualité des Logiciels
            $table->text('note2_lsi3_s5'); //Audit et Sécurité Intélligentedes systèmes d’informations 
            $table->text('note3_lsi3_s5'); //Systèmes d’informations décisionnel et data mininig
            $table->text('note4_lsi3_s5'); //Cloud Intelligence et virtulisation
            $table->text('note5_lsi3_s5'); //Géodecisionnel et Systèmes d’informations géographiques
            $table->text('note6_lsi3_s5'); //Intelligence économique

            $table->text('note_lsi3_pfe'); //Projet de fin d’études


        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('semestres');
    }
}
