<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('users')->insert([
            'name' => "Admin",
            'email' =>'admin@hotmail.com',
            'password' => bcrypt('pass1234'),
            'Role'=>'admin',
            'CNE' =>'k503030',
            'photo'=>'http://megaicons.net/static/img/icons_sizes/51/200/512/admin-icon.png',
            'classe'=>'Admin',
        ]);
        DB::table('users')->insert([
            'name' => "prof1",
            'email' =>'prof1@hotmail.com',
            'password' => bcrypt('pass1234'),
            'Role'=>'Professeur',
            'CNE' =>'k52010',
            'photo'=>'http://megaicons.net/static/img/icons_sizes/51/200/512/admin-icon.png',
            'classe'=>'Professeur',
        ]);
        DB::table('users')->insert([
            'name' => "prof2",
            'email' =>'prof2@hotmail.com',
            'password' => bcrypt('pass1234'),
            'Role'=>'Professeur',
            'CNE' =>'k52011',
            'photo'=>'http://megaicons.net/static/img/icons_sizes/51/200/512/admin-icon.png',
            'classe'=>'Professeur',
        ]);
        DB::table('users')->insert([
            'name' => "Saad joudi",
            'email' =>'joudii_1994@hotmail.com',
            'password' => bcrypt('pass1234'),
            'Role'=>'Student',
            'CNE' =>'k502253',
            'photo'=>'http://megaicons.net/static/img/icons_sizes/51/200/512/admin-icon.png',
            'classe'=>'LSI1',
        ]);
        DB::table('users')->insert([
            'name' => "Faiza qasmi",
            'email' =>'faiza@hotmail.com',
            'password' => bcrypt('pass1234'),
            'Role'=>'student',
            'CNE' =>'k502254',
            'photo'=>'http://megaicons.net/static/img/icons_sizes/51/200/512/admin-icon.png',
            'classe'=>'LSI1',
        ]);
    }
}
