<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

class AdminController extends Controller
{
     // function return administration view 
    public function administration()
    {
    	return view('administration');
    }
    // function return list of students in lsi1
    public function lsi1()
    {
        $users = DB::table('users')->get();

        return view('lsi1', ['users' => $users]);
    	
    }
     // function return list of students in lsi2
    public function lsi2()
    {
        $users = DB::table('users')->get();

        return view('lsi2', ['users' => $users]);
        
    }
     // function return list of students in lsi3
    public function lsi3()
    {
        $users = DB::table('users')->get();

        return view('lsi3', ['users' => $users]);
        
    }
      // funtion to update admin

    public function getUpdateUserAdmin()
    {
        $users = DB::table('users')->get();
        $user_id = $_POST["user_id"];
        return view('updateUserAdmin',['users'=>$users,'user_id'=>$user_id]);
    }
}
