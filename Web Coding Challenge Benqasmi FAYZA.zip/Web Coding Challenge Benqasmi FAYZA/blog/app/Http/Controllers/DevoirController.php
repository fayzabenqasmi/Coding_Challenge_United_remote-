<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Redirect;
use App\Devoir;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DevoirController extends Controller
{
    // function to publish our duty 
   public function publierDevoir()
   {	 // create new instance of Devoir object and affect it to variable devoir  
         $devoir = new Devoir();
       // Affect information to the object attributes 
   		$devoir->body = $_POST["body"];
   		$devoir->classe = $_POST["classe"];
   		$devoir->user_id= $_POST["id-user"];
   		$devoir->titre  = $_POST["titre"];
   		$devoir->save();
   		return Redirect::to('/professeurPage');
   }
   // function return all duty approprite to the specific professor
   public function getProfesseurDevoir()
   {
      $devoirs = DB::table('devoirs')->get();
      return view('devoirsProfesseur',['devoirs'=>$devoirs]);
   }
    // function return all publications 
   public function getPublications()
   {
      $devoirs = DB::table('devoirs')->get();
      $users   = DB::table('users')->get();
      return view('getPublications',['devoirs'=>$devoirs,'users'=> $users]);
   }
}
