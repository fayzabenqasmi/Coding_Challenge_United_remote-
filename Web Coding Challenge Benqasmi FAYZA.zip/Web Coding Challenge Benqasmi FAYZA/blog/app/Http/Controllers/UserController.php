<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;

class UserController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    // return profile 
    public function profil()
    {
        return view('profil');
    }
     // function return view where we can modify  our profile 
    public function modifierProfil()
    {
        return view('modifierProfil');
    }
}
