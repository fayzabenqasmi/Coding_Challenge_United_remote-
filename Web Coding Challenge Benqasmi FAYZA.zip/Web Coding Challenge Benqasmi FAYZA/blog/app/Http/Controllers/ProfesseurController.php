<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProfesseurController extends Controller
{
     // return view for professor 
    public function getProfesseurPage()
    {
    	return view('professeurPage');
    }
}
