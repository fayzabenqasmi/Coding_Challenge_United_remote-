@extends('layouts.app')
@section('content')
<div class="container">

	<h2 style="margin-bottom:50px; padding:10px" class="bg-primary">Vos publications : </h2>
	<div class="row">
	<div class="col-md-12" style="margin-bottom:20px"><a href="professeurPage" class="btn btn-success glyphicon glyphicon-arrow-left"> Retour </a></div>
	@foreach($devoirs as $devoir )
		@if (Auth::user()->id == $devoir->user_id)
		  <div class="col-sm-4">
		    <div class="thumbnail" style="border-top-right-radius: 50px;border-bottom-left-radius: 80px">
		     
		      <div class="caption">
		        <h3 style="text-align:center;"><span style="color:#3097D1;text-decoration: underline;">{{ $devoir->classe }} : {{ $devoir->titre }}</span></h3>
		        <p style="text-align:center;margin-bottom:30px;font-style: italic;"> Publie le :{{ $devoir->created_at }}</p>
		        <p style="text-align:center">{{ $devoir->body}}</p>
		        <form method="POST" action="supprimerDevoir">
		        	{{ csrf_field() }}
			        <input type="hidden" name="id_devoir" value="{{ $devoir->id }}">
			        <p style="text-align:center"><input type="submit" class="btn btn-primary" role="button" value="Supprimer"></p>
		        </form>
		      </div>
		    </div>
		  </div>
		
		@endif
	@endforeach
	</div>
</div>
 
@endsection