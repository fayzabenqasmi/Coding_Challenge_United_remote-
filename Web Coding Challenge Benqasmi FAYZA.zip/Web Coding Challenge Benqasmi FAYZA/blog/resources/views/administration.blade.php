@extends('layouts.app')
@section('content')
<div class="container">
    <div class="col-md-12">
        <h3 style="text-align: center;padding:10px" class="bg-primary"> Filièree LSI  : </h3>
        <div class="list-group" style="text-align: center">
          <a href="{{ route('lsi1') }}" class="list-group-item">LSI 1</a>
          <a href="{{ route('lsi2') }}" class="list-group-item">LSI 2</a>
          <a href="{{ route('lsi3') }}" class="list-group-item">LSI 3</a>
        </div>
    </div>
    
    <div class="col-md-9">
    	<a style="margin-top:62px;;padding:10px" href="{{ route('getPublications') }}" class="btn btn-primary lg"> Consulter les publications </a>
    </div>

</div>
@endsection