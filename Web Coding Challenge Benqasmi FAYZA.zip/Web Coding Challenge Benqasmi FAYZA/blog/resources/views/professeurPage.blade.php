@extends('layouts.app')
@section('content')
<div class="container">


		<h1> Bonjour monsieur {{ Auth::user()->name }} </h1>
		<a type="button" href="getPublierDevoir" class="btn btn-primary btn-lg">Publier</a>
		<a type="button" href="getProfesseurDevoir" class="btn btn-success btn-lg">Afficher mes publications</a>
	
</div>
@endsection