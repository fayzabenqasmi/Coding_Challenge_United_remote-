@extends('layouts.app')

@section('content')
<div class="container">

	<h1 style="margin-bottom:50px;padding:10px" class="bg-primary">Filiere {{ Auth::user()->classe }}: </h1>
	<div class="row">
    @foreach($devoirs as $devoir)
        @if( $devoir->classe == Auth::user()->classe )
        	@foreach($users as $user)
        		@if( $user->id == $devoir->user_id)

				  <div class="col-sm-4">
				    <div class="thumbnail" style="border-top-right-radius: 50px;border-bottom-left-radius: 80px">
				     
				      <div class="caption">
				        <h3 style="text-align:center;"><span style="color:#3097D1;text-decoration: underline;"> {{ $devoir->titre }}</span></h3>
				        <p style="text-align:center;margin-bottom:30px;font-style: italic;"> Publie le :{{ $devoir->created_at }} par : {{ $user->name }}</p>
				        <p style="text-align:center">{{ $devoir->body}}</p>	
				        </form>
				      </div>
				    </div>
				  </div>



        		@endif
            @endforeach
        @endif
    @endforeach
    </div>
</div>
@endsection
