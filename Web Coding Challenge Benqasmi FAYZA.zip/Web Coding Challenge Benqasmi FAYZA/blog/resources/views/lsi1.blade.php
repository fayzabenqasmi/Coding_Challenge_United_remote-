@extends('layouts.app')
@section('content')
<div class="container">
	 		<div class="col-md-3"><a href="administration" class="btn btn-primary glyphicon glyphicon-arrow-left"> Retour </a></div>
		    <div class="col-md-12">
		        <h3 style="text-align:center;padding:10px" class="bg-primary">Etudiants de lsi 1 </h3>
		         <div class="row" style="margin-top:50px">
		      	 @foreach ($users as $user)
		   		 @if ($user->classe == 'LSI1')
			        <div class="col-sm-4">
			            <div class="card">
			                <canvas class="header-bg" width="250" height="70" id="header-blur"></canvas>
			                <div class="avatar">
			                    <img style="width:100px" src="{{ $user->photo }}" alt="" />
			                </div>
			                <div class="content">
			                    <p>{{ $user->name }} <br>
			                       CNE : {{ $user->CNE }} <br>
			                       EMAIL : {{$user->email }} <br>	

			                    </p>
								<form method="POST" action="deleteUser">
									 {{ csrf_field() }}			 	   
									<input type="hidden" value="{{ $user->id }}" name="user_id">                
				                    <p><input type="submit" class="btn btn-danger" value="supprimer">
			                    </form>

								<form method="POST" action="getUpdateUserAdmin">
									 {{ csrf_field() }}			 	   
									<input type="hidden" value="{{ $user->id }}" name="user_id">                
				                    <input type="submit" class="btn btn-primary" value="Modifier"></p>			
			                    </form> 

			                    <form method="POST" action="afficherNotes">
			                    {{ csrf_field() }}
			                    	<input type="hidden" name="user_id" value="{{ $user->id }}">
			                    	<input type="submit" name="submit" class="btn btn-success" value="Modifier notes">
			                    </form>           
			                </div>
			            </div>
			        </div>
		   		 @endif
		   		 @endforeach
		   		</div>
			</div>
	
</div>
@endsection