<?php
use App\User;
use App\Devoir;
use App\Semestre;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

//Route::get('/profil','UserController@profil')->name('profil');

//Route::get('/modifierProfil','UserController@modifierProfil')->name('modifierProfil');
Route::get('/profil',[
	'uses' => 'UserController@profil',
	'as'   => 'profil',
	'middleware'=>'auth'
	]);
Route::get('/modifierProfil',[
	'uses' => 'UserController@modifierProfil',
	'as'   => 'modifierProfil',
	'middleware'=>'auth'
	]);

Route::post('modifierProfilFunction', function()
{
	$user = Auth::user();
	$user->name = $_POST["name"];
	$user->CNE  = $_POST["CNE"];
	$user->email = $_POST["email"];
	$user->photo = $_POST["photo"];
	$user->classe =$_POST["classe"];
	$user->password = bcrypt($_POST["password"]);
	
	$user->save();
	return Redirect::to('/profil');

});

Route::get('administration',[
	'uses' => 'AdminController@administration',
	'as'   => 'administration'
	]);

Route::get('lsi1',[
	'uses' => 'AdminController@lsi1',
	'as'   => 'lsi1'
	]);

Route::get('lsi2',[
	'uses' => 'AdminController@lsi2',
	'as'   => 'lsi2'
	]);

Route::get('lsi3',[
	'uses' => 'AdminController@lsi3',
	'as'   => 'lsi3'
	]);

Route::post('deleteUser',function(){
	$id = $_POST["user_id"];
	$user = User::find($id);    
	$user->forceDelete();
	return Redirect::to('/administration');
});

Route::post('getUpdateUserAdmin',[
	'uses' => 'AdminController@getUpdateUserAdmin',
	'as'   => 'getUpdateUserAdmin'
]);

Route::post('modifierProfilAdmin',function(){
	$id = $_POST["user_id"];

	$user = User::find($id);
	$user->name = $_POST["name"];
	$user->CNE  = $_POST["CNE"];
	$user->email = $_POST["email"];
	$user->photo = $_POST["photo"];
	$user->classe =$_POST["classe"];
	$user->password = bcrypt($_POST["password"]);
	
	$user->save();
	return Redirect::to('/administration');
});

Route::get('professeurPage',[
	'uses' => 'ProfesseurController@getProfesseurPage',
	'as'   => 'professeurPage'
]);

Route::get('getPublierDevoir',function(){

	return view('publierDevoir');
});

Route::post('publierDevoir',[
	'uses' => 'DevoirController@publierDevoir',
	'as'   => 'publierDevoir'
	]);

Route::get('getProfesseurDevoir',[
	'uses'=>'DevoirController@getProfesseurDevoir',
	'as'  =>'getProfesseurDevoir'
	]);

Route::post('supprimerDevoir',function()
{
	$devoir = Devoir::find($_POST["id_devoir"]);
	$devoir->forceDelete();
	return Redirect::to('/getProfesseurDevoir');
});

Route::get('publications', function()
{
	$devoirs = DB::table('devoirs')->get();
	$users   = DB::table('users')->get();
	return view('publications',['devoirs'=>$devoirs, 'users'=>$users]);
})->name('publications');

Route::get('getPublications',[
	'uses' => 'DevoirController@getPublications',
	'as'   => 'getPublications'
	]);

Route::post('supprimerDevoirById',function(){
	$devoir = Devoir::find($_POST["id_devoir"]);
	$devoir->forceDelete();
	return Redirect::to('/getPublications');
});

Route::post('afficherNotes',function(){
	$notes = DB::table('semestres')->get();
	$users = DB::table('users')->get();
	$id_user = $_POST["user_id"];
	return view('notes',['notes'=> $notes,'id_user'=> $id_user, 'users'=>$users ]);
});
Route::post('modifierNoteView',function(){
	$note = $_POST["note"];
	$id_user = $_POST["id_user"];
	$matiere = $_POST["matiere"];
	$semestre = DB::table('semestres')->get();
	return view('modifierNoteView',[ 'matiere'=>$matiere , 'note'=>$note ,'id_user'=>$id_user ]);
});

Route::post('modifierNote', function(){
	$nouvelle_note = $_POST["nouvelle_note"];
	$matiere       = $_POST["note"];
	$user_id       = $_POST["id_user"];
	$semestre      = Semestre::where('user_id','=',$user_id)->first();
	$semestre->$matiere = $nouvelle_note;
	$semestre->save();
	return Redirect::to('/administration');
});

Route::get('getNotesEtudiant',function(){
	$notes = DB::table('semestres')->get();
	$users = DB::table('users')->get();
	return view('notesEtudiant',['notes'=> $notes, 'users'=>$users ]);
})->name('getNotesEtudiant');